basic=6.50
standard=18.75
luxury=29.50
choice=input("Basic, Standard or Luxury carpet?\n")
if choice=="Basic" or choice=="basic":
    area=float(input("How big of an area is the carpet?\n"))
    print(f"It will cost you {area * basic}$")
elif choice=="Standard" or choice=="standard":
    area=float(input("How big of an area is the carpet?\n"))
    print(f"It will cost you {area * standard}$")
elif choice=="Luxury" or choice=="luxury":
    area=float(input("How big of an area is the carpet?\n"))
    print(f"It will cost you {area*luxury}$")
else:
    print("Not a valid option")