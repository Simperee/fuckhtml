flour=float(input("How many cups of flours are you converting?\n"))
sugar=float(input("How many cups of sugar are you converting?\n"))
print("Grams of sugar: "+str(sugar*201)+"grams of flour: "+str(flour*128)+"g")