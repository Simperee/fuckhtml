import random

r="Rock"
p="Paper"
s="Scissors"

choice = input("What will you be choosing?\nRock\nPaper\nScissors\n")

computer_choices = [r, p, s]
computer_choice = random.choice(computer_choices)

if choice.capitalize() == computer_choice:
    print(f"You and the computer have tied!\nThe computer chose: {computer_choice}")
elif choice.capitalize() == r:
    if computer_choice == p:
        print(f"You lost!\nThe computer chose: {computer_choice}")
    if computer_choice == s:
        print(f"You won!\nThe computer chose: {computer_choice}")
elif choice.capitalize() == p:
    if computer_choice == s:
        print(f"You lost!\nThe computer chose: {computer_choice}")
    if computer_choice == r:
        print(f"You won!\nThe computer chose: {computer_choice}")
elif choice.capitalize() == s:
    if computer_choice == r:
        print(f"You lost!\nThe computer chose: {computer_choice}")
    if computer_choice == p:
        print(f"You won!\nThe computer chose: {computer_choice}")