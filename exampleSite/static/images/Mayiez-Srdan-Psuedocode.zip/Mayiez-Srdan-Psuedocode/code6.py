ratings=[6,5,5.5,6.5,4.5,5,8]
print(f"Average: {sum(ratings)/len(ratings)}")