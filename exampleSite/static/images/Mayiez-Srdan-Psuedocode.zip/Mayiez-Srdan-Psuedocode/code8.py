from count_timer import CountTimer
from w8ing import wait
import tkinter as tk
import tkinter.font as tkFont

i=0

def pressed():
    t = CountTimer(duration=float(3))
    t.start()
    while t.remaining != 0:
        root.update()
        traffic_light.config(fg="#ffbf00", text="The traffic light is amber")
    else:
        traffic_light.config(fg="#ff0000", text="The traffic light is red")
    t = CountTimer(duration=float(2))
    t.start()
    while t.remaining != 0:
        root.update()
    else:
        pedestrian_light.config(fg="#00ff00", text="The pedestrian light is green")
    t = CountTimer(duration=float(8))
    t.start()
    while t.remaining != 0:
        root.update()
    else:
        pedestrian_light.config(fg="#00ff00", text="The pedestrian light is blinking")
    t = CountTimer(duration=float(4))
    t.start()
    while t.remaining != 0:
        root.update()
    else:
        pedestrian_light.config(fg="#ff0000", text="The pedestrian light is red")
        traffic_light.config(fg="#ffbf00", text="The traffic light is amber")
    t = CountTimer(duration=float(2))
    t.start()
    while t.remaining != 0:
        root.update()
    else:
        traffic_light.config(fg="#00ff00", text="The traffic light is green")

def traffic_control():
    pressed()
    while i==0:
        t = CountTimer(duration=float(60))
        t.start()
        while t.remaining != 0:
            root.update()
        else:
            pressed()

root=tk.Tk()

root.title("Light")
width=600
height=500
screenwidth = root.winfo_screenwidth()
screenheight = root.winfo_screenheight()
alignstr = '%dx%d+%d+%d' % (width, height, (screenwidth - width) / 2, (screenheight - height) / 2)
root.geometry(alignstr)
root.resizable(width=False, height=False)

traffic_light = tk.Label(root)
ft = tkFont.Font(family='Comic Sans MS', size=15)
traffic_light["font"] = ft
traffic_light["fg"] = "#00ff00"
traffic_light["justify"] = "center"
traffic_light["text"] = "The traffic light is green"
traffic_light.place(x=100, y=120, width=350, height=30)

pedestrian_light = tk.Label(root)
pedestrian_light["font"] = ft
pedestrian_light["fg"] = "#ff0404"
pedestrian_light["justify"] = "center"
pedestrian_light["text"] = "The pedestrian light is red"
pedestrian_light.place(x=70, y=150, width=450, height=30)

button = tk.Button(root)
button["bg"] = "#f0f0f0"
button["font"] = ft
button["fg"] = "#000000"
button["justify"] = "center"
button["text"] = "Button"
button.place(x=220, y=180, width=70, height=25)
button["command"] = traffic_control

root.mainloop()