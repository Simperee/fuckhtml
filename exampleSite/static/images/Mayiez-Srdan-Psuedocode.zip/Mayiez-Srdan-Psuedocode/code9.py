import os
import random
lives=3

numbers=[1,2,3,4,5]

choice=random.choice(numbers)-1

words=["wond","ixte","lalb","sone","kobo"]
results=["down","exit","ball","nose","book"]

while lives >=1:
    print(f"The scrambled word is: {words[choice]}")
    guess = input("What is the word?\n")
    if guess == results[choice]:
        print(f"You won!\nThe answer was: {results[choice]}\nYou guessed it in {4-lives} try/tries.")
        os._exit(12)
    else:
        lives -= 1
else:
    print(f"You lost!\nThe word was: {results[choice]}")