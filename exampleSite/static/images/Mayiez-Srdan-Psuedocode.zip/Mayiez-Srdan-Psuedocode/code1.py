password="1234"
guess=input("What is the password?\n")
while guess != password:
    print("Incorrect Password")
    guess = input("What is the password?\n")
print("Correct!\nWelcome Admin.")